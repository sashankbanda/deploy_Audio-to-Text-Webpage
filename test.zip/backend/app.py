from flask import Flask, request, jsonify
import os
from pydub import AudioSegment
from transformers import pipeline
from librosa import load
import numpy as np
import warnings

# Initialize Flask app
app = Flask(__name__)

# Set up environment variables for FFMPEG and suppress warnings
ffmpeg_path = "D:\\0000 study spacd\\hackathon ✨\\11 Upgrading_query_pdf\\ffmpeg\\ffmpeg\\bin\\ffmpeg.exe"
os.environ["FFMPEG_BINARY"] = ffmpeg_path
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"
os.environ["HF_HUB_DISABLE_SYMLINKS_WARNING"] = "1"
warnings.filterwarnings("ignore", category=FutureWarning)

# Initialize the Hugging Face pipeline for audio transcription
transcriber = pipeline(
    model="openai/whisper-small",
    task="automatic-speech-recognition",
    device="cpu"
)

def convert_to_wav(input_path, output_path):
    try:
        audio = AudioSegment.from_file(input_path)
        audio.export(output_path, format="wav")
    except Exception as e:
        raise RuntimeError(f"Failed to convert to WAV: {e}")

def split_audio_with_overlap(audio, sr, max_duration=30, overlap=5):
    max_samples = int(max_duration * sr)
    overlap_samples = int(overlap * sr)
    start = 0
    chunks = []

    while start < len(audio):
        end = start + max_samples
        chunks.append(audio[start:end])
        start = end - overlap_samples
        if end > len(audio):
            break

    return chunks

def transcribe_audio(audio_path):
    try:
        audio, sr = load(audio_path, sr=16000)
        if len(audio.shape) > 1:
            audio = np.mean(audio, axis=0)

        audio_chunks = split_audio_with_overlap(audio, sr)

        full_transcription = []
        for chunk in audio_chunks:
            result = transcriber(chunk)
            if isinstance(result, dict) and "text" in result:
                full_transcription.append(result["text"])

        return " ".join(full_transcription).strip()
    except Exception as e:
        raise RuntimeError(f"Failed to transcribe audio: {e}")

@app.route('/transcribe', methods=['POST'])
def transcribe():
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400

    audio_file = request.files['file']
    input_path = "uploaded_audio.mp3"
    wav_path = "converted_audio.wav"

    try:
        audio_file.save(input_path)
        convert_to_wav(input_path, wav_path)
        transcription = transcribe_audio(wav_path)

        return jsonify({'transcription': transcription})
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        if os.path.exists(input_path):
            os.remove(input_path)
        if os.path.exists(wav_path):
            os.remove(wav_path)

if __name__ == '__main__':
    app.run(debug=True)
